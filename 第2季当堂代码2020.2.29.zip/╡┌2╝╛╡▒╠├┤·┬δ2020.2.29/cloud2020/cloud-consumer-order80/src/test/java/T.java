/**
 * @auther zzyy
 * @create 2020-02-19 20:39
 */
public class T
{
    public static void main(String[] args)
    {
        System.out.println(Integer.MAX_VALUE);
    }
}
