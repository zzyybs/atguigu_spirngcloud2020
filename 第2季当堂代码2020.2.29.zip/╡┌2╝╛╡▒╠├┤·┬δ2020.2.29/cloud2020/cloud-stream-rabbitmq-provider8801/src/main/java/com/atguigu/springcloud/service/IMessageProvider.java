package com.atguigu.springcloud.service;

/**
 * @auther zzyy
 * @create 2020-02-22 10:55
 */
public interface IMessageProvider
{
    public String send();
}
