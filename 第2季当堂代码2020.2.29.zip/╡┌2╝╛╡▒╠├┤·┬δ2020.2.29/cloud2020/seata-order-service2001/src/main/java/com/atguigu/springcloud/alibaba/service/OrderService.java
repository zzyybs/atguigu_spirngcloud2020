package com.atguigu.springcloud.alibaba.service;

import com.atguigu.springcloud.alibaba.domain.Order;

/**
 * @auther zzyy
 * @create 2020-02-26 15:19
 */
public interface OrderService
{
    void create(Order order);
}
